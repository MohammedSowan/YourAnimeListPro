/*
class WelcomeFragment : Fragment() {
 //   private lateinit var binding: FragmentWelcomeBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       // binding = FragmentWelcomeBinding.inflate(inflater,container,false)
        val name = requireArguments().getString("user_name")
        val email = requireArguments().getString("user_email")
        binding.apply {
        /*    tvWelcomeName.text = name
            tvWelcomeEmail.text = email
            btnViewTerms.setOnClickListener {
             it.findNavController().navigate(R.id.action_welcomeFragment_to_termsFragment)
            }*/
        }
        return binding.root
    }

}*/